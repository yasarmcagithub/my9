<?php 
require_once('conn.php');
//     session_start();
//     // echo $_SESSION['page'];
//     $page= $_SESSION['page'];

// //limit set

//     $limit=5;

//     $start=$page*$limit;
//     echo $start;


// echo'<td>'.$_POST['searchinfo'].'</td>';
    if (isset($_POST['searchinfo'])) 

    {

    $condition=$_POST['searchinfo'];
    // $sql="SELECT * FROM personal_detail";
    // $sql="SELECT * FROM  personal_detail WHERE CONCAT(first_name,last_name,email,gender,mobile_no,addr1,addr2,country,state,city,pincode)LIKE '%$condition%'";
    // $sql="SELECT * from (personal_detail inner join country ON personal_detail.country=country.C_id INNER join state on personal_detail.state=state.s_id) WHERE CONCAT(first_name,last_name,email,gender,mobile_no,addr1,addr2,country,state,city,pincode,state_name,country_name)LIKE '%$condition%'";
    $sql="SELECT * from (personal_detail inner join country ON personal_detail.country=country.C_id INNER join state on personal_detail.state=state.s_id) WHERE first_name LIKE '%$condition%' || last_name LIKE '%$condition%' || email LIKE '%$condition%'|| gender LIKE '%$condition%'|| mobile_no LIKE '%$condition%'|| addr1 LIKE '%$condition%'|| addr2 LIKE '%$condition%'|| country_name LIKE '%$condition%'|| state_name LIKE '%$condition%'|| city LIKE '%$condition%'|| pincode LIKE '%$condition%'";
    // echo $sql; //check query
    $run=$conn->query($sql);

    foreach ($run as $row) 
    {
    	echo "<tr>";
    	echo "<td><input type='checkbox'></td>";
    	echo "<td>".$row['first_name']."</td>";
    	echo "<td>".$row['last_name']."</td>";
    	echo "<td>".$row['email']."</td>";
    	echo "<td>".$row['gender']."</td>";
    	echo "<td>".$row['mobile_no']."</td>";
    	echo "<td>".$row['addr1']."</td>";
    	echo "<td>".$row['addr2']."</td>";
    	echo "<td>".$row['country_name']."</td>";
    	echo "<td>".$row['state_name']."</td>";
    	echo "<td>".$row['city']."</td>";
    	echo "<td>".$row['pincode']."</td>";
    	echo "<td><a href='personal_detail.php' ><img src='edit.png' height='20px' width='20px'></a></td>";
    	echo "<td><img src='delete.png' height='20px' width='20px'></td>";
    	echo "</tr>";
    } 

    }//if end
   
 ?>