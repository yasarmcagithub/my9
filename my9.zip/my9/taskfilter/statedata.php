<?php
require_once('conn.php');
	// echo isset($_POST['country']);

if(isset($_POST['country']))
{
	$country=$_POST["country"];
// 	foreach ($country as $state) {
// 		echo $state;
// 	}
$sql="SELECT * FROM state WHERE c_id='$country'";
$run=mysqli_query($conn,$sql);

     	echo "<option value=''>Select</option>";
   	 while($row=$run->fetch_assoc()) 
	{
		 // echo "<option value =".$i."">".$array[$country][$i]."</option>";
		echo "<option value=\"".$row['s_id']."\">".$row['state_name']."</option>";

	}

}


?>